export const init={
    name:'Sachin',
    loc:'Mumbia',
    runs:10000
}