import D from "./D";
export default D;
