import "./Contact.css";
import React from "react";

function template() {
  return (
    <div className="contact">
      <h1>Contact</h1>
    </div>
  );
};

export default template;
