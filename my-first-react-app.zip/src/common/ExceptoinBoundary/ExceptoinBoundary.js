import React    from "react";
import template from "./ExceptoinBoundary.jsx";

class ExceptoinBoundary extends React.Component {
  state={
    hasException:false,
    message:''
  }
  static getDerivedStateFromError(exceptionInfo){
    return {
      hasException:true,
      message:exceptionInfo.message
    }
  }

  componentDidCatch(exceptionInfo,stackInfo){
      console.log(':::',exceptionInfo);
      console.log('...',stackInfo)
  }
  render() {
    return template.call(this);
  }
}

export default ExceptoinBoundary;
