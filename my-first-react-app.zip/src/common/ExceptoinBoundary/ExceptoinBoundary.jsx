import "./ExceptoinBoundary.css";
import React from "react";

function template() {
  return (
    <div className="exceptoin-boundary">
        {this.state.hasException ? <h1>{this.state.message}</h1> :this.props.children}
    </div>
  );
};

export default template;
