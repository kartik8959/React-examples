import "./Exceptions.css";
import React from "react";
import Hero from './Hero/index'
import ExceptoinBoundary from '../common/ExceptoinBoundary/index'
function template() {
  return (
    <div className="exceptions">
      <h1>Exceptions</h1>
      <ExceptoinBoundary>
          <Hero name='Spider Man'/>
      </ExceptoinBoundary>
      <ExceptoinBoundary>
      <Hero name='Super Man' />
      </ExceptoinBoundary>

      <ExceptoinBoundary>
          <Hero name='Joker' />
      </ExceptoinBoundary>
      
    </div>
  );
};

export default template;
