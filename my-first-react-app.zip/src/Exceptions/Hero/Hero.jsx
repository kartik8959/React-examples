import "./Hero.css";
import React from "react";

function template() {
  if(this.props.name == 'Joker'){
    throw new Error('You are not a Hero')
  }
  return (
    <div className="hero">
      <h1>I am {this.props.name}</h1>
    </div>
  );
};

export default template;
