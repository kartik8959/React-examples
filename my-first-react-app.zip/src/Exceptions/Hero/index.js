import Hero from "./Hero";
export default Hero;
