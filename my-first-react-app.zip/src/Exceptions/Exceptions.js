import React    from "react";
import template from "./Exceptions.jsx";

class Exceptions extends React.Component {
  render() {
    return template.call(this);
  }
}

export default Exceptions;
