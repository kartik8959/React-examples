import "./Menu.css";
import React,{lazy,Suspense} from "react";
import {HashRouter,Routes,Route} from 'react-router-dom'

// import Home from '../Home/index'
// import About from '../About/index';
// import Contact from '../Contact/index';

const Home=lazy(()=>import('../Home/index'))
const About=lazy(()=>import('../About/index'))
const Contact=lazy(()=>import('../Contact/index'))
const Exceptions =lazy(()=>import('../Exceptions/index'));
const Hoc =lazy(()=>import('../HOC/index'))

function template() {
  return (
    <div className="menu">
          <div className="menu-items">
            <a href="#/home">Home</a>
            <a href="#/about">About</a>
            <a href="#/contact">Contact</a>
            <a href="#/exceptions">Exception Handling</a>
            <a href="#/hoc">HOC</a>

          </div>
          <Suspense fallback="Loading...">
            <HashRouter>
                  <Routes>
                    <Route path="/" element={<Home />} />
                      <Route path="/home" element={<Home />} />
                      <Route path="/about" element={<About />} />
                      <Route path="/contact" element={<Contact />} />
                      <Route path="/exceptions" element={<Exceptions />} />
                      <Route path="/hoc" element={<Hoc />} />

                  </Routes>
            </HashRouter>
          </Suspense>
    </div>
  );
};

export default template;
