import "./HOC.css";
import React from "react";
import BtnClick from './BtnClick/index';
import TextHover from './TextHover/index'
function template() {
  
  return (
    <div className="hoc">
      <h1>HOC</h1>
      <BtnClick />
      <TextHover/>
    </div>
  );
};

export default template;
