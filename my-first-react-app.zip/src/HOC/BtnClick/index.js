import BtnClick from "./BtnClick";
export default BtnClick;
