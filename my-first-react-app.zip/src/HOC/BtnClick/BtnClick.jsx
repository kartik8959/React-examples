import "./BtnClick.css";
import React from "react";

function template() {
  return (
    <div className="btn-click">
        <button onClick={()=>this.props.fnIncrementCnt()}>He clicked me {this.props.cnt} time(s)</button>
    </div>
  );
};

export default template;
