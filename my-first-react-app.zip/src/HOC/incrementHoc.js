import React from "react";


const incrementHoc=(Comp)=>{
    class MyComp extends React.Component{
        state={
            cnt:0
        }
        fnIncrementCnt=()=>{
            this.setState({
                cnt:this.state.cnt+1
            })
        }
        render(){
            return <Comp fnIncrementCnt={this.fnIncrementCnt} cnt={this.state.cnt} />
        }
    }
    return MyComp;
}

export default incrementHoc;


