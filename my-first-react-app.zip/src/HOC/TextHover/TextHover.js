import React    from "react";
import template from "./TextHover.jsx";
import incrementHoc from '../incrementHoc'
class TextHover extends React.Component {

  render() {
    return template.call(this);
  }
}

export default incrementHoc(TextHover)
