import "./TextHover.css";
import React from "react";

function template() {
  return (
    <div className="text-hover">
      <h1 onMouseOver={()=>this.props.fnIncrementCnt()}>He Hover me {this.props.cnt} time(s)</h1>
    </div>
  );
};

export default template;
