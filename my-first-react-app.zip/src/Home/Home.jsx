import "./Home.css";
import React from "react";
import Salary from './Salary/index';
import ExceptoinBoundary from '../common/ExceptoinBoundary/index'
function template() {
  return (
    <div className="home">
      <h1>Home</h1>
       <ExceptoinBoundary>
       <Salary emp="E1" amt='1000' />
       </ExceptoinBoundary>
       <ExceptoinBoundary>
       <Salary emp="E2" amt='-2000' />

       </ExceptoinBoundary>

    </div>
  );
};

export default template;
