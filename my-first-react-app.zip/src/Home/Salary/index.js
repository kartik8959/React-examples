import Salary from "./Salary";
export default Salary;
