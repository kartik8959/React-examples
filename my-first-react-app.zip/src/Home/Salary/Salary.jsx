import "./Salary.css";
import React from "react";

function template() {
  const {amt,emp}=this.props
  if(amt<0){
    throw new Error('Salary should Positive')
  }
  return (
    <div className="salary">
      <h1>This is {emp}, my Salary is {amt} .</h1>
    </div>
  );
};

export default template;
