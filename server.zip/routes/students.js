var express=require('express')
var router=express.Router()
var mongodb=require('mongodb')

router.post('/reg-std',function(req,res,next){//receive the request
   //take the data from req 
     const {uid,pwd,gender,country}=req.body
     var document={
      uid,pwd,gender,country
     }
   // conn with db 
      var url='mongodb://localhost:27017'

      var mongoClient=mongodb.MongoClient

      mongoClient.connect(url)
      .then(function(server){
             var db= server.db('school')
             var collection=db.collection('students')
             collection.insertOne(document)
             .then(function(result){
                res.send(result)
             })
             .catch(function(result){
                res.send(result)
             })

      })
      .catch(function(){
        res.send('db connection error')
      })

   // perform some operations 


   // send res back

})

router.get('/login/:uid/:pwd',function(req,res,next){//receive the req
     const {uid,pwd}= req.params
     const data={uid,pwd}
     const url='mongodb://localhost:27017';

     const mongoClient=mongodb.MongoClient;

     mongoClient.connect(url,function(err,server){
              if(err){
                 res.send('db con error')
              }else{
                  var db=server.db('school')
                  var collection=db.collection('students')
                  collection.find(data).toArray(function(e,s){
                      if(e){
                         res.send(e);
                      }else{
                         res.send(s)
                      }
                  })
              }
     })
})


module.exports=router;