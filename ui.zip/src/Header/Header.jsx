import "./Header.css";
import React from "react";

function template() {
  return (
    <div className="header bg-primary text-white text-center">
        End To End Flow
    </div>
  );
};

export default template;
