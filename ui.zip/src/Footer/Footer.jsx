import "./Footer.css";
import React from "react";

function template() {
  return (
    <div className="footer bg-primary text-white text-center">
       &copy; rights belongs to me.
    </div>
  );
};

export default template;
