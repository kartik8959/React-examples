export const init={
    isLoggedIn:false
}