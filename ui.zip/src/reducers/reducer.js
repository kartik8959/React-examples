import {init} from '../utils/init'
export const reducer=(state=init,action)=>{
    return state
}