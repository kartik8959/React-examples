import React from 'react'

export const AfterLogin = () => {
  return (
    <div>AfterLogin</div>
  )
}
