export const init={
    name:'',
    loc:'',
    runs:''
}