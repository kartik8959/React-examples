import React from 'react';
import logo from './logo.svg';
import './App.css';

/*
type TestProps={
   name:string
}
const Test=(props:TestProps)=>{
  return <div>{props.name.length} </div>
}
*/

/*
type TestProps={
  players:string[]
}
class Test extends React.Component<TestProps>{
  render() {
      return <div>{this.props.players[0]}</div>
  }
}
function App() {
  return (
    <div className="App">
        <Test players={['Sachin','Dhoni']} />
    </div>
  );
}

*/

/*
type TestProps={
  players:(string|number)[]
}
class Test extends React.Component<TestProps>{
  render() {
      return <div>{this.props.players[0]}</div>
  }
}

*/

/*
type TestProps={
   data:{
     fn:string,
     ln:string
   }
}
const Test=(props:TestProps)=>{
    return <h1>{props.data.fn} ----{props.data.ln} </h1>
}
*/

/*

type TestProps={
  data:{n:string}[]
}
const Test=(props:TestProps)=>{
   return <h1>{props.data[1].n} </h1>
}

*/

/*
type TestProps={
  opt:'D'|'S'
}
const Test=(props:TestProps)=>{
   return <h1>
     {props.opt == 'S' && 'Sachin'}
     {props.opt == 'D' && 'Dhoni'}
   </h1>
}
*/
/*
type TestProps={
   name?:string
}
const Test=(props:TestProps)=>{
  return <h1>
      {props.name ? props.name : 'Sachin'}
  </h1>
}
*/
/*
type TypeCnt=number|string|boolean
const Test=()=>{
  const [cnt,setCnt]=React.useState<(TypeCnt)>(0);
  const fnClick=()=>{
      setCnt(cnt+'1')
  }
  return <div>
    <h1>{cnt}</h1>
    <button onClick={fnClick}>click</button>
  </div>
}
*/

/*
type TestProps={
  children:React.ReactNode
  }
const Test=(props:TestProps)=>{
  return <div>
       {props.children}
  </div>
}
*/

/*
type TestProps={
f1:(e:React.ChangeEvent<HTMLInputElement>)=>void,
f2:()=>void
}
const Test=(props:TestProps)=>{
  return <div>
       <input onChange={props.f1} />
       <button onClick={props.f2}>click</button>
  </div>
}

function App() {

  const change=(e:any)=>{
    console.log(e.target.value)
  }
  const click=()=>{
    console.log('click called')
  }

  return (
    <div className="App">
        <Test f1={change} f2={click}/>
         
    </div>
  );
}

*/

type TestProps={
 myStyles:React.CSSProperties
}
const Test=(props:TestProps)=>{
  return <span style={props.myStyles}>Sachin</span>
}
function App() {


  return (
    <div className="App">
        <Test myStyles={{color:'red',fontSize:'30px'}} />
         
    </div>
  );
}
export default App;
