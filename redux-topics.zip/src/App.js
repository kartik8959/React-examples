import logo from './logo.svg';
import './App.css';
import Users from './Users/index'
import Photos from './Photos/index';
import Posts from './Posts/index';
function App() {
  return (
    <div className="App">
      <Users />
      <Photos />
      <Posts />
    </div>
  );
}

export default App;
