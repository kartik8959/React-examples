import "./Photos.css";
import React from "react";

function template() {
  return (
    <div className="photos">
      <h1>Photos</h1>
      <button onClick={this.fnGetPhotos}>Get Photos</button>
    </div>
  );
};

export default template;
