import React    from "react";
import template from "./Photos.jsx";
import {store} from '../store/myStore'
class Photos extends React.Component {
  render() {
    return template.call(this);
  }
  fnGetPhotos=()=>{
    //call saga function 
    
    store.dispatch({
      type:'GET_PHOTOS'
    })
  }
}

export default Photos;
