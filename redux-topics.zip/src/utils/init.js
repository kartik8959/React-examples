export const usersInit={
    users:[]
}

export const sagaInit={
    photos:[],
    posts:[]
}