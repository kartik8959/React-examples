import React    from "react";
import template from "./Posts.jsx";
import {store} from '../store/myStore'

class Posts extends React.Component {
  render() {
    return template.call(this);
  }
  fnGetPosts(){
     store.dispatch({
       type:'GET_POSTS'
     })
  }
}

export default Posts;
