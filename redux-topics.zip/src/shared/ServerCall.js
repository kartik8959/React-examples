import axios from 'axios'

class ServerCall{

   static get(url){
        return axios.get(url) 
    }
    static post(){

    }
}

export default ServerCall;