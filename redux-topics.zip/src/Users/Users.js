import React    from "react";
import template from "./Users.jsx";
import usersAction from "../actions/usersActions.js";
class Users extends React.Component {
  fnGetUsers=()=>{
        usersAction()
  }
  render() {
    return template.call(this);
  }
}

export default Users;
