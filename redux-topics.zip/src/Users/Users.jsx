import "./Users.css";
import React from "react";

function template() {
  return (
    <div className="users">
      <h1>Users</h1>
      <button onClick={this.fnGetUsers}>Get Users</button>
    </div>
  );
};

export default template;
