import ServerCall from "../shared/ServerCall"
import {store} from '../store/myStore'
const usersAction=()=>{
    ServerCall.get('https://jsonplaceholder.typicode.com/users')
    .then((res)=>{
        let users=res.data;
        store.dispatch({
            type:'UPDATE_USERS',
            data:users
        })
    })
    .catch((res)=>{
        console.log(res)
    })
}

export default usersAction
