import {takeLatest,call,put} from 'redux-saga/effects'
import ServerCall from '../shared/ServerCall'
function* getPhotos(){
  const res=  yield call(ServerCall.get,'https://jsonplaceholder.typicode.com/photos')
  if(res.status==200){
    yield put({
        type:'UPDATE_PHOTOS',
        data:res.data
    })
  }
}

function* insertPhotos(){

}

function* photosSaga(){
    //1. getPhotos
    yield takeLatest('GET_PHOTOS',getPhotos)

    //2. insertPhotos
    yield takeLatest('INSERT_PHOTOS',insertPhotos)
}

export default photosSaga