import {takeLatest,call, put} from 'redux-saga/effects'
import ServerCall from '../shared/ServerCall';

function* getPosts(){
  const res=  yield call(ServerCall.get,'https://jsonplaceholder.typicode.com/posts')
  if(res.status==200){
    yield put({
      type:'UPDATE_POSTS',
      data:res.data
    })
  }
}

function* deletePosts(){
    
}

function* postsSaga(){
    // getposts
      yield takeLatest('GET_POSTS',getPosts);

    // delete Posts
    yield takeLatest('DELETE_POSTS',deletePosts);

}

export default postsSaga;