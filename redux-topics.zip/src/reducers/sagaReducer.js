import {sagaInit} from '../utils/init'

const sagaReducer=(state=sagaInit,action)=>{
  switch(action.type){
      case 'UPDATE_PHOTOS':
          state={
              ...state,
              photos:action.data
          }
          break;
      case 'UPDATE_POSTS':
        state={
            ...state,
            posts:action.data
        }
          break;
  }
  return state;
}

export default sagaReducer;