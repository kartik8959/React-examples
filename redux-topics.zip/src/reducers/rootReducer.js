import {combineReducers} from 'redux';
import userReducer from './userReducer';
import sagaReducer from './sagaReducer';

export const rootReducer=combineReducers({userReducer,sagaReducer})
