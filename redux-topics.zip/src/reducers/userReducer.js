import {usersInit} from '../utils/init'
const userReducer=(state=usersInit,action)=>{
   switch(action.type){
       case 'UPDATE_USERS':
           state={
               ...state,
               users:action.data
           }
           break;
   }
   return state;
}

export default userReducer;
